# Volcan TV — دليل التشغيل

## 1) السيرفر (Supabase، مجاني للبداية)
1. أنشئ مشروعًا على supabase.com
2. Authentication > Providers > Email: **عطّل "Confirm email"**
3. SQL Editor: الصق محتوى `backend/schema.sql` ونفّذه
4. Project Settings > API: انسخ `Project URL` و `anon public key`

## 2) لوحة الإدارة
1. افتح `admin/index.html` وضع URL و KEY في أعلى السكربت
2. ارفعه على أي استضافة (Netlify / Cloudflare Pages / GitHub Pages) أو افتحه محليًا
3. أنشئ أول حساب من التطبيق، ثم نفّذ في SQL Editor:
   `update profiles set is_admin = true where username = 'اسمك';`
4. ادخل اللوحة: ولّد أكواد، أضف قنوات، مدّد اشتراكات

## 3) التطبيق (Flutter)
1. ثبّت Flutter ثم داخل مجلد app نفّذ: `flutter create . --platforms=android`
   (يولّد مجلد android، ولن يمسّ lib/main.dart ولا pubspec.yaml)
2. في `android/app/src/main/AndroidManifest.xml` أضف داخل <manifest>:
   `<uses-permission android:name="android.permission.INTERNET"/>`
   وداخل <application> الخاصية: `android:usesCleartextTraffic="true"`
3. ضع URL و anon key في `lib/main.dart`
4. `flutter pub get` ثم `flutter run` للتجربة
5. ملف APK للتوزيع: `flutter build apk --release`
   (استبدل أيقونة التطبيق بشعارك عبر حزمة flutter_launcher_icons)

## ملاحظات أمان
- الـ anon key عام بطبيعته، والحماية تتم عبر سياسات RLS الموجودة في schema.sql
- القنوات لا تُرجَع إلا لمشترك فعّال (حماية على مستوى قاعدة البيانات)
- استخدم فقط مصادر بث تملك حق توزيعها
