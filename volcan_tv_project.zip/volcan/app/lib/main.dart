import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

// ===== ضع بيانات مشروعك هنا (Supabase > Project Settings > API) =====
const kUrl = 'https://YOUR-PROJECT.supabase.co';
const kAnon = 'YOUR-ANON-KEY';
// ====================================================================

const kOrange = Color(0xFFFF5A1F);
final sb = Supabase.instance.client;
String emailOf(String u) => '${u.trim().toLowerCase()}@volcan.app';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: kUrl, anonKey: kAnon);
  runApp(const VolcanApp());
}

class VolcanApp extends StatelessWidget {
  const VolcanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Volcan TV',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF12161B),
          colorScheme: const ColorScheme.dark(primary: kOrange),
          inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
        ),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Gate(),
      );
}

/// يقرر أي شاشة تظهر: دخول / تفعيل / الرئيسية
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Map<String, dynamic>? profile;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    sb.auth.onAuthStateChange.listen((_) => load());
    load();
  }

  Future<void> load() async {
    if (sb.auth.currentUser == null) {
      if (mounted) setState(() { profile = null; loading = false; });
      return;
    }
    final p = await sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle();
    if (mounted) setState(() { profile = p; loading = false; });
  }

  bool get active {
    final e = profile?['expires_at'];
    return e != null && DateTime.parse(e).isAfter(DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (profile == null) return AuthPage(onDone: load);
    if (!active) return ActivatePage(onDone: load);
    return HomePage(profile: profile!, onChanged: load);
  }
}

class Logo extends StatelessWidget {
  const Logo({super.key});
  @override
  Widget build(BuildContext context) => const Column(children: [
        Icon(Icons.local_fire_department, size: 72, color: kOrange),
        Text('VOLCAN TV', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, letterSpacing: 1)),
      ]);
}

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class AuthPage extends StatefulWidget {
  final VoidCallback onDone;
  const AuthPage({super.key, required this.onDone});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final u = TextEditingController(), p = TextEditingController();
  bool reg = false, busy = false;

  Future<void> submit() async {
    final name = u.text.trim().toLowerCase();
    if (name.length < 3 || p.text.length < 6) {
      toast(context, 'الاسم 3 أحرف على الأقل وكلمة المرور 6 على الأقل');
      return;
    }
    setState(() => busy = true);
    try {
      if (reg) {
        await sb.auth.signUp(email: emailOf(name), password: p.text, data: {'username': name});
      } else {
        await sb.auth.signInWithPassword(email: emailOf(name), password: p.text);
      }
      widget.onDone();
    } on AuthException catch (e) {
      if (mounted) toast(context, reg ? 'تعذّر إنشاء الحساب (الاسم مستخدم؟)' : 'بيانات الدخول غير صحيحة');
      debugPrint(e.message);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const Logo(),
                const SizedBox(height: 32),
                TextField(controller: u, decoration: const InputDecoration(labelText: 'اسم المستخدم')),
                const SizedBox(height: 12),
                TextField(controller: p, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور')),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: FilledButton(onPressed: busy ? null : submit, child: Text(reg ? 'إنشاء حساب' : 'دخول')),
                ),
                TextButton(
                  onPressed: () => setState(() => reg = !reg),
                  child: Text(reg ? 'لديك حساب؟ سجّل الدخول' : 'ليس لديك حساب؟ أنشئ حسابًا'),
                ),
              ]),
            ),
          ),
        ),
      );
}

class ActivatePage extends StatefulWidget {
  final VoidCallback onDone;
  const ActivatePage({super.key, required this.onDone});
  @override
  State<ActivatePage> createState() => _ActivatePageState();
}

class _ActivatePageState extends State<ActivatePage> {
  final c = TextEditingController();
  bool busy = false;

  Future<void> redeem() async {
    setState(() => busy = true);
    try {
      await sb.rpc('redeem_code', params: {'p_code': c.text});
      widget.onDone();
    } catch (_) {
      if (mounted) toast(context, 'كود غير صالح أو مستخدم');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const Logo(),
                const SizedBox(height: 24),
                const Text('تفعيل الاشتراك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('أدخل كود التفعيل الذي حصلت عليه من الموزّع', textAlign: TextAlign.center),
                const SizedBox(height: 20),
                TextField(
                  controller: c,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.ltr,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(hintText: 'VOLCAN-XXXX'),
                ),
                const SizedBox(height: 16),
                SizedBox(width: double.infinity, height: 48, child: FilledButton(onPressed: busy ? null : redeem, child: const Text('تفعيل'))),
                TextButton(onPressed: () => sb.auth.signOut(), child: const Text('تسجيل الخروج')),
              ]),
            ),
          ),
        ),
      );
}

class HomePage extends StatefulWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const HomePage({super.key, required this.profile, required this.onChanged});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  String cat = 'الكل';
  List<Map<String, dynamic>> channels = [];

  @override
  void initState() {
    super.initState();
    sb.from('channels').select().eq('active', true).order('name').then((r) {
      if (mounted) setState(() => channels = List<Map<String, dynamic>>.from(r));
    });
  }

  @override
  Widget build(BuildContext context) {
    final cats = ['الكل', ...{...channels.map((e) => e['category'] as String)}];
    final list = channels.where((e) => cat == 'الكل' || e['category'] == cat).toList();
    final exp = DateTime.parse(widget.profile['expires_at']).toLocal();
    final left = exp.difference(DateTime.now()).inDays;

    return Scaffold(
      appBar: AppBar(title: const Text('VOLCAN TV', style: TextStyle(fontWeight: FontWeight.w800))),
      body: tab == 0
          ? Column(children: [
              SizedBox(
                height: 56,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.all(8),
                  children: [
                    for (final c in cats)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(label: Text(c), selected: cat == c, onSelected: (_) => setState(() => cat = c)),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.3),
                  itemCount: list.length,
                  itemBuilder: (_, i) => InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(name: list[i]['name'], url: list[i]['stream_url']))),
                    child: Ink(
                      decoration: BoxDecoration(color: const Color(0xFF1D232B), borderRadius: BorderRadius.circular(16)),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        const Icon(Icons.play_circle_fill, size: 40, color: kOrange),
                        const SizedBox(height: 8),
                        Text(list[i]['name'], style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text(list[i]['category'], style: const TextStyle(color: Colors.grey, fontSize: 12)),
                      ]),
                    ),
                  ),
                ),
              ),
            ])
          : ListView(padding: const EdgeInsets.all(16), children: [
              ListTile(title: const Text('المستخدم'), trailing: Text(widget.profile['username'])),
              ListTile(title: const Text('ينتهي في'), trailing: Text('${exp.year}-${exp.month}-${exp.day}')),
              ListTile(title: const Text('الأيام المتبقية'), trailing: Text('$left')),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ActivatePage(onDone: () { Navigator.pop(context); widget.onChanged(); }))),
                child: const Text('تجديد / إدخال كود'),
              ),
              TextButton(onPressed: () => sb.auth.signOut(), child: const Text('تسجيل الخروج')),
            ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.tv), label: 'القنوات'),
          NavigationDestination(icon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class PlayerPage extends StatefulWidget {
  final String name, url;
  const PlayerPage({super.key, required this.name, required this.url});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final VideoPlayerController vc;
  ChewieController? cc;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    vc = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => cc = ChewieController(videoPlayerController: vc, autoPlay: true, isLive: true, aspectRatio: vc.value.aspectRatio));
      });
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    cc?.dispose();
    vc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.name)),
        body: Center(child: cc == null ? const CircularProgressIndicator() : Chewie(controller: cc!)),
      );
}
