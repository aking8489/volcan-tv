-- أمثلة لإضافة قنوات يدويًا. استبدل الروابط بروابط بث رسمية/مرخّصة تملك حق استخدامها.
-- تأكد من عمل كل رابط في مشغّل VLC قبل إضافته.
insert into channels(name, category, stream_url) values
 ('NASA TV', 'علوم', 'https://nasa-i.akamaihd.net/hls/live/253565/NTV-Public1/master.m3u8'),
 ('قناة تجريبية 1', 'أخبار', 'https://example.com/live/news.m3u8'),
 ('قناة تجريبية 2', 'رياضة', 'https://example.com/live/sport.m3u8');
