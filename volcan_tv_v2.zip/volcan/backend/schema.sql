-- Volcan TV: شغّل هذا الملف كاملًا في Supabase > SQL Editor
create table profiles(
  id uuid primary key references auth.users on delete cascade,
  username text unique not null,
  expires_at timestamptz,
  is_admin boolean not null default false,
  created_at timestamptz default now());
create table codes(
  code text primary key,
  days int not null check (days > 0),
  used_by uuid references profiles(id),
  used_at timestamptz,
  created_at timestamptz default now());
create table channels(
  id bigserial primary key,
  name text not null,
  category text default 'عام',
  stream_url text not null,
  active boolean default true);

alter table profiles enable row level security;
alter table codes enable row level security;
alter table channels enable row level security;

create function is_admin() returns boolean language sql security definer stable as
$$ select coalesce((select is_admin from profiles where id = auth.uid()), false) $$;
create function is_active() returns boolean language sql security definer stable as
$$ select coalesce((select expires_at > now() from profiles where id = auth.uid()), false) $$;

create policy "own or admin read" on profiles for select using (id = auth.uid() or is_admin());
create policy "admin update" on profiles for update using (is_admin());
create policy "admin codes" on codes for all using (is_admin()) with check (is_admin());
create policy "subscribers read channels" on channels for select using ((active and is_active()) or is_admin());
create policy "admin channels" on channels for all using (is_admin()) with check (is_admin());

-- إنشاء ملف المستخدم تلقائيًا عند التسجيل
create function handle_new_user() returns trigger language plpgsql security definer as $$
begin
  insert into profiles(id, username) values (new.id, lower(new.raw_user_meta_data->>'username'));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- تفعيل كود (يستدعيه التطبيق)
create function redeem_code(p_code text) returns timestamptz language plpgsql security definer as $$
declare c codes; new_exp timestamptz;
begin
  select * into c from codes where code = upper(trim(p_code)) and used_by is null for update;
  if not found then raise exception 'invalid_code'; end if;
  update profiles set expires_at = greatest(now(), coalesce(expires_at, now())) + (c.days || ' days')::interval
    where id = auth.uid() returning expires_at into new_exp;
  update codes set used_by = auth.uid(), used_at = now() where code = c.code;
  return new_exp;
end $$;

-- تمديد اشتراك مستخدم (للأدمن فقط)
create function admin_extend(p_user uuid, p_days int) returns void language plpgsql security definer as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  update profiles set expires_at = greatest(now(), coalesce(expires_at, now())) + (p_days || ' days')::interval where id = p_user;
end $$;

-- بعد إنشاء حسابك من التطبيق، اجعله أدمن:
-- update profiles set is_admin = true where username = 'اسمك';
