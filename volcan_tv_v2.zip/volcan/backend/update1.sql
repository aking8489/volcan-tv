-- تحديث 1: شعارات القنوات + المفضلة + حد الأجهزة (نفّذه بعد schema.sql)
alter table channels add column logo_url text;
alter table profiles add column max_devices int not null default 1;

create table favorites(
  user_id uuid not null default auth.uid() references profiles(id) on delete cascade,
  channel_id bigint not null references channels(id) on delete cascade,
  primary key (user_id, channel_id));
alter table favorites enable row level security;
create policy "own favorites" on favorites for all using (user_id = auth.uid()) with check (user_id = auth.uid());

create table devices(
  user_id uuid not null references profiles(id) on delete cascade,
  device_id text not null,
  created_at timestamptz default now(),
  primary key (user_id, device_id));
alter table devices enable row level security;
create policy "admin devices" on devices for all using (is_admin()) with check (is_admin());

create function register_device(p_device text) returns void language plpgsql security definer as $$
declare n int; m int;
begin
  if exists (select 1 from devices where user_id = auth.uid() and device_id = p_device) then return; end if;
  select count(*) into n from devices where user_id = auth.uid();
  select max_devices into m from profiles where id = auth.uid();
  if n >= m then raise exception 'device_limit'; end if;
  insert into devices(user_id, device_id) values (auth.uid(), p_device);
end $$;

create function admin_reset_devices(p_user uuid) returns void language plpgsql security definer as $$
begin
  if not is_admin() then raise exception 'forbidden'; end if;
  delete from devices where user_id = p_user;
end $$;
