-- تحديث 2: أقسام القنوات (مباشر / أفلام / مسلسلات / Sports)
alter table channels add column kind text not null default 'live'
  check (kind in ('live','movie','series','sports'));
