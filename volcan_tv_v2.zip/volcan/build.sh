#!/bin/bash
set -e
cd "$(dirname "$0")/app"
flutter create . --platforms=android --org com.volcan --project-name volcan_tv
python3 - <<'PY'
p = "android/app/src/main/AndroidManifest.xml"
s = open(p).read()
s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application android:usesCleartextTraffic="true"', 1)
open(p, "w").write(s)
PY
flutter pub get
dart run flutter_launcher_icons || echo "icons skipped"
flutter build apk --release --dart-define=SB_URL="$SB_URL" --dart-define=SB_KEY="$SB_KEY"
