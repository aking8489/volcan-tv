import 'dart:math';

import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

// ===== ضع بيانات مشروعك هنا (Supabase > Project Settings > API) =====
const kUrl = String.fromEnvironment('SB_URL', defaultValue: 'https://YOUR-PROJECT.supabase.co');
const kAnon = String.fromEnvironment('SB_KEY', defaultValue: 'YOUR-ANON-KEY');
// ====================================================================

const kOrange = Color(0xFFFF5A1F);
final sb = Supabase.instance.client;
Future<String> deviceId() async {
  final sp = await SharedPreferences.getInstance();
  var id = sp.getString('did');
  if (id == null) {
    id = '${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 31)}';
    await sp.setString('did', id);
  }
  return id;
}

String emailOf(String u) => '${u.trim().toLowerCase()}@volcan.app';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await Supabase.initialize(url: kUrl, anonKey: kAnon);
  runApp(const VolcanApp());
}

class VolcanApp extends StatelessWidget {
  const VolcanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Volcan TV',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF12161B),
          colorScheme: const ColorScheme.dark(primary: kOrange),
        ),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Gate(),
      );
}

/// يقرر أي شاشة تظهر: دخول / تفعيل / الرئيسية
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Map<String, dynamic>? profile;
  bool loading = true, blocked = false;

  @override
  void initState() {
    super.initState();
    sb.auth.onAuthStateChange.listen((_) => load());
    load();
  }

  Future<void> load() async {
    if (sb.auth.currentUser == null) {
      if (mounted) setState(() { profile = null; loading = false; });
      return;
    }
    final p = await sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle();
    var b = false;
    if (p != null) {
      try {
        await sb.rpc('register_device', params: {'p_device': await deviceId()});
      } catch (_) {
        b = true;
      }
    }
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) setState(() { profile = p; blocked = b; loading = false; });
  }

  bool get active {
    final e = profile?['expires_at'];
    return e != null && DateTime.parse(e).isAfter(DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: Logo(size: 140)));
    if (blocked) return const DeviceLimitPage();
    if (profile == null) return AuthPage(onDone: load);
    if (!active) return ActivatePage(onDone: load);
    return HomePage(profile: profile!, onChanged: load);
  }
}

class Logo extends StatelessWidget {
  final double size;
  const Logo({super.key, this.size = 110});
  @override
  Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
        ClipRRect(borderRadius: BorderRadius.circular(size * .22), child: Image.asset('assets/logo.png', width: size, height: size)),
        const SizedBox(height: 10),
        const Text('VOLCAN TV', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 1)),
      ]);
}

class DeviceLimitPage extends StatelessWidget {
  const DeviceLimitPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Logo(),
              const SizedBox(height: 24),
              const Text('تم الوصول للحد الأقصى من الأجهزة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('هذا الحساب مرتبط بجهاز آخر. تواصل مع الموزّع لإعادة ضبط الأجهزة.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              OutlinedButton(onPressed: () => sb.auth.signOut(), child: const Text('تسجيل الخروج')),
            ]),
          ),
        ),
      );
}

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class AuthPage extends StatefulWidget {
  final VoidCallback onDone;
  const AuthPage({super.key, required this.onDone});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final u = TextEditingController(), p = TextEditingController();
  bool reg = false, busy = false;

  Future<void> submit() async {
    final name = u.text.trim().toLowerCase();
    if (name.length < 3 || p.text.length < 6) {
      toast(context, 'الاسم 3 أحرف على الأقل وكلمة المرور 6 على الأقل');
      return;
    }
    setState(() => busy = true);
    try {
      if (reg) {
        await sb.auth.signUp(email: emailOf(name), password: p.text, data: {'username': name});
      } else {
        await sb.auth.signInWithPassword(email: emailOf(name), password: p.text);
      }
      widget.onDone();
    } on AuthException catch (e) {
      if (mounted) toast(context, (reg ? 'تعذّر إنشاء الحساب: ' : 'تعذّر الدخول: ') + e.message);
      debugPrint(e.message);
    } catch (e) {
      if (mounted) toast(context, 'خطأ: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const Logo(),
                const SizedBox(height: 32),
                TextField(controller: u, decoration: const InputDecoration(labelText: 'اسم المستخدم')),
                const SizedBox(height: 12),
                TextField(controller: p, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور')),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: FilledButton(onPressed: busy ? null : submit, child: Text(reg ? 'إنشاء حساب' : 'دخول')),
                ),
                TextButton(
                  onPressed: () => setState(() => reg = !reg),
                  child: Text(reg ? 'لديك حساب؟ سجّل الدخول' : 'ليس لديك حساب؟ أنشئ حسابًا'),
                ),
              ]),
            ),
          ),
        ),
      );
}

class ActivatePage extends StatefulWidget {
  final VoidCallback onDone;
  const ActivatePage({super.key, required this.onDone});
  @override
  State<ActivatePage> createState() => _ActivatePageState();
}

class _ActivatePageState extends State<ActivatePage> {
  final c = TextEditingController();
  bool busy = false;

  Future<void> redeem() async {
    setState(() => busy = true);
    try {
      await sb.rpc('redeem_code', params: {'p_code': c.text});
      widget.onDone();
    } catch (_) {
      if (mounted) toast(context, 'كود غير صالح أو مستخدم');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const Logo(),
                const SizedBox(height: 24),
                const Text('تفعيل الاشتراك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('أدخل كود التفعيل الذي حصلت عليه من الموزّع', textAlign: TextAlign.center),
                const SizedBox(height: 20),
                TextField(
                  controller: c,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.ltr,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(hintText: 'VOLCAN-XXXX'),
                ),
                const SizedBox(height: 16),
                SizedBox(width: double.infinity, height: 48, child: FilledButton(onPressed: busy ? null : redeem, child: const Text('تفعيل'))),
                TextButton(onPressed: () => sb.auth.signOut(), child: const Text('تسجيل الخروج')),
              ]),
            ),
          ),
        ),
      );
}

class ChannelsPage extends StatefulWidget {
  final String kind, title;
  const ChannelsPage({super.key, required this.kind, required this.title});
  @override
  State<ChannelsPage> createState() => _ChannelsPageState();
}

class _ChannelsPageState extends State<ChannelsPage> {
  int tab = 0;
  String cat = 'الكل', q = '';
  List<Map<String, dynamic>> channels = [];
  Set<int> favs = {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    var qb = sb.from('channels').select().eq('active', true);
    if (widget.kind != 'all') qb = qb.eq('kind', widget.kind);
    final r = await qb.order('name');
    final f = await sb.from('favorites').select('channel_id');
    if (!mounted) return;
    setState(() {
      channels = List<Map<String, dynamic>>.from(r);
      favs = {for (final x in f) x['channel_id'] as int};
    });
  }

  Future<void> toggleFav(int id) async {
    if (favs.contains(id)) {
      setState(() => favs.remove(id));
      await sb.from('favorites').delete().eq('channel_id', id);
    } else {
      setState(() => favs.add(id));
      await sb.from('favorites').insert({'channel_id': id});
    }
  }

  Widget grid(List<Map<String, dynamic>> list) {
    if (list.isEmpty) return const Center(child: Text('لا توجد قنوات', style: TextStyle(color: Colors.grey)));
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.15),
      itemCount: list.length,
      itemBuilder: (_, i) {
        final c = list[i];
        final id = c['id'] as int;
        final logo = c['logo_url'] as String?;
        return InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(name: c['name'], url: c['stream_url']))),
          child: Ink(
            decoration: BoxDecoration(
              gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF24313A), Color(0xFF11181D)]),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0x44D4AF37)),
            ),
            child: Stack(children: [
              Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  icon: Icon(favs.contains(id) ? Icons.favorite : Icons.favorite_border, color: kOrange, size: 20),
                  onPressed: () => toggleFav(id),
                ),
              ),
              Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  SizedBox(
                    height: 48,
                    child: (logo != null && logo.isNotEmpty)
                        ? Image.network(logo, errorBuilder: (_, __, ___) => const Icon(Icons.play_circle_fill, size: 40, color: kOrange))
                        : const Icon(Icons.play_circle_fill, size: 40, color: kOrange),
                  ),
                  const SizedBox(height: 8),
                  Text(c['name'], textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(c['category'] ?? '', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                ]),
              ),
            ]),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final cats = ['الكل', ...{...channels.map((e) => (e['category'] ?? 'عام') as String)}];
    bool match(Map<String, dynamic> e) => (cat == 'الكل' || e['category'] == cat) && (q.isEmpty || (e['name'] as String).toLowerCase().contains(q.toLowerCase()));
    final list = channels.where(match).toList();
    final favList = channels.where((e) => favs.contains(e['id']) && (q.isEmpty || (e['name'] as String).toLowerCase().contains(q.toLowerCase()))).toList();

    Widget search() => Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
          child: TextField(
            onChanged: (v) => setState(() => q = v),
            decoration: const InputDecoration(hintText: 'ابحث عن قناة...', prefixIcon: Icon(Icons.search), isDense: true),
          ),
        );

    final pages = <Widget>[
      Column(children: [
        search(),
        SizedBox(
          height: 56,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(8),
            children: [
              for (final c in cats)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(label: Text(c), selected: cat == c, onSelected: (_) => setState(() => cat = c)),
                ),
            ],
          ),
        ),
        Expanded(child: RefreshIndicator(onRefresh: load, child: grid(list))),
      ]),
      Column(children: [search(), Expanded(child: grid(favList))]),
    ];

    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.tv), label: 'القنوات'),
          NavigationDestination(icon: Icon(Icons.favorite), label: 'المفضلة'),
        ],
      ),
    );
  }
}

const kGold = Color(0xFFD4AF37);
const kGoldLight = Color(0xFFF3D77A);

/// خلفية بخطوط ذهبية مائلة
class StripesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final thin = Paint()..color = const Color(0x14D4AF37)..strokeWidth = 1.2;
    for (double x = -size.height; x < size.width; x += 44) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), thin);
    }
    final band = Paint()..color = const Color(0x1AD4AF37)..strokeWidth = 18;
    canvas.drawLine(Offset(size.width * .15, size.height), Offset(size.width * .55, 0), band);
    canvas.drawLine(Offset(size.width * .62, size.height), Offset(size.width * 1.0, 0), band);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class GoldTile extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final double iconSize, fs;
  final bool live;
  const GoldTile({super.key, required this.icon, required this.label, required this.onTap, this.iconSize = 44, this.fs = 17, this.live = false});
  @override
  State<GoldTile> createState() => _GoldTileState();
}

class _GoldTileState extends State<GoldTile> {
  bool focus = false, hover = false;
  bool get on => focus || hover;

  @override
  Widget build(BuildContext context) => FocusableActionDetector(
        onShowFocusHighlight: (v) => setState(() => focus = v),
        onShowHoverHighlight: (v) => setState(() => hover = v),
        actions: {ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (_) { widget.onTap(); return null; })},
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedScale(
            scale: on ? 1.04 : 1,
            duration: const Duration(milliseconds: 160),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF24313A), Color(0xFF11181D)]),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: on ? kGoldLight : const Color(0x55D4AF37), width: on ? 2 : 1),
                boxShadow: [BoxShadow(color: on ? kGold.withOpacity(.4) : Colors.black54, blurRadius: on ? 20 : 8, offset: const Offset(0, 4))],
              ),
              child: Stack(children: [
                if (widget.live)
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(color: const Color(0xFFD71920), borderRadius: BorderRadius.circular(20)),
                      child: const Text('● LIVE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      padding: EdgeInsets.all(widget.iconSize * .32),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [kGold.withOpacity(.28), Colors.transparent]),
                      ),
                      child: ShaderMask(
                        shaderCallback: (r) => const LinearGradient(colors: [kGoldLight, kGold, Color(0xFF9C7A1C)], begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(r),
                        child: Icon(widget.icon, size: widget.iconSize, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(widget.label, textAlign: TextAlign.center, style: TextStyle(fontSize: widget.fs, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ]),
            ),
          ),
        ),
      );
}

/// الشاشة الرئيسية بتصميم القائمة الذهبية
class HomePage extends StatelessWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const HomePage({super.key, required this.profile, required this.onChanged});

  void open(BuildContext c, String kind, String title) =>
      Navigator.push(c, MaterialPageRoute(builder: (_) => ChannelsPage(kind: kind, title: title)));

  Widget small(IconData icon, VoidCallback onTap) => Expanded(
        child: GoldTile(icon: icon, label: '', onTap: onTap, iconSize: 22, fs: 0),
      );

  @override
  Widget build(BuildContext context) {
    final exp = DateTime.parse(profile['expires_at']).toLocal();
    final date = '${exp.day}/${exp.month}/${exp.year}';
    final left = exp.difference(DateTime.now()).inDays;
    const gap = SizedBox(width: 12, height: 12);
    return Scaffold(
      body: Container(
        color: const Color(0xFF0A0906),
        child: CustomPaint(
          painter: StripesPainter(),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
              child: Column(children: [
                Row(children: [
                  Expanded(
                    child: Align(
                      alignment: AlignmentDirectional.centerStart,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: const Color(0x33D4AF37), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0x66D4AF37))),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.verified, size: 16, color: kGold),
                          const SizedBox(width: 6),
                          Text('ينتهي $date  ·  $left يوم', style: const TextStyle(fontSize: 12.5)),
                        ]),
                      ),
                    ),
                  ),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.asset('assets/logo.png', height: 44)),
                    const SizedBox(width: 10),
                    ShaderMask(
                      shaderCallback: (r) => const LinearGradient(colors: [kGoldLight, kGold]).createShader(r),
                      child: const Text('VOLCAN TV', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, letterSpacing: 1.5, color: Colors.white)),
                    ),
                  ]),
                  Expanded(
                    child: Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: Text('أهلاً، ${profile['username']}', style: const TextStyle(fontSize: 13, color: Colors.grey)),
                    ),
                  ),
                ]),
                const SizedBox(height: 12),
                Expanded(
                  child: Row(children: [
                    Expanded(
                      flex: 5,
                      child: Column(children: [
                        Expanded(
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              gradient: const LinearGradient(begin: Alignment.topRight, end: Alignment.bottomLeft, colors: [Color(0xFF0B0B0B), Color(0xFF2A210D), Color(0xFF0B0B0B)]),
                              border: Border.all(color: const Color(0x88D4AF37)),
                              boxShadow: const [BoxShadow(color: Color(0x33FF5A1F), blurRadius: 24)],
                            ),
                            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Expanded(child: Padding(padding: const EdgeInsets.all(14), child: Image.asset('assets/logo.png', fit: BoxFit.contain))),
                              const Padding(
                                padding: EdgeInsets.only(bottom: 10),
                                child: Text('كل قنواتك في مكان واحد', style: TextStyle(color: kGold, fontSize: 13)),
                              ),
                            ]),
                          ),
                        ),
                        gap,
                        SizedBox(
                          height: 58,
                          child: Row(children: [
                            small(Icons.settings, () => Navigator.push(context, MaterialPageRoute(builder: (_) => AccountPage(profile: profile, onChanged: onChanged)))),
                            gap,
                            small(Icons.refresh, () { onChanged(); toast(context, 'تم التحديث'); }),
                            gap,
                            small(Icons.exit_to_app, () => SystemNavigator.pop()),
                          ]),
                        ),
                      ]),
                    ),
                    gap,
                    Expanded(
                      flex: 5,
                      child: Column(children: [
                        Expanded(child: GoldTile(icon: Icons.format_list_numbered, label: 'المسلسلات', onTap: () => open(context, 'series', 'المسلسلات'))),
                        gap,
                        Expanded(child: GoldTile(icon: Icons.autorenew, label: 'تجديد الاشتراك', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ActivatePage(onDone: () { Navigator.pop(context); onChanged(); }))))),
                      ]),
                    ),
                    gap,
                    Expanded(
                      flex: 5,
                      child: Column(children: [
                        Expanded(child: GoldTile(icon: Icons.movie_outlined, label: 'أفلام', onTap: () => open(context, 'movie', 'أفلام'))),
                        gap,
                        Expanded(child: GoldTile(icon: Icons.sports_soccer, label: 'Sports', onTap: () => open(context, 'sports', 'Sports'))),
                      ]),
                    ),
                    gap,
                    Expanded(flex: 6, child: GoldTile(icon: Icons.live_tv, label: 'مباشر', iconSize: 80, fs: 26, live: true, onTap: () => open(context, 'live', 'مباشر'))),
                  ]),
                ),
                const SizedBox(height: 4),
                const Align(alignment: Alignment.bottomLeft, child: Text('v1.0', style: TextStyle(fontSize: 14, color: Colors.grey))),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class AccountPage extends StatelessWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const AccountPage({super.key, required this.profile, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    final exp = DateTime.parse(profile['expires_at']).toLocal();
    final left = exp.difference(DateTime.now()).inDays;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Center(child: Logo(size: 80)),
        const SizedBox(height: 16),
        ListTile(title: const Text('المستخدم'), trailing: Text(profile['username'])),
        ListTile(title: const Text('ينتهي في'), trailing: Text('${exp.year}-${exp.month}-${exp.day}')),
        ListTile(title: const Text('الأيام المتبقية'), trailing: Text('$left')),
        const SizedBox(height: 12),
        TextButton(onPressed: () { Navigator.pop(context); sb.auth.signOut(); }, child: const Text('تسجيل الخروج')),
      ]),
    );
  }
}

class PlayerPage extends StatefulWidget {
  final String name, url;
  const PlayerPage({super.key, required this.name, required this.url});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final VideoPlayerController vc;
  ChewieController? cc;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    vc = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => cc = ChewieController(videoPlayerController: vc, autoPlay: true, isLive: true, aspectRatio: vc.value.aspectRatio));
      });
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    cc?.dispose();
    vc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.name)),
        body: Center(child: cc == null ? const CircularProgressIndicator() : Chewie(controller: cc!)),
      );
}
