import 'dart:math';

import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

// ===== ضع بيانات مشروعك هنا (Supabase > Project Settings > API) =====
const kUrl = String.fromEnvironment('SB_URL', defaultValue: 'https://YOUR-PROJECT.supabase.co');
const kAnon = String.fromEnvironment('SB_KEY', defaultValue: 'YOUR-ANON-KEY');
// ====================================================================

const kOrange = Color(0xFFFF5A1F);
final sb = Supabase.instance.client;
Future<String> deviceId() async {
  final sp = await SharedPreferences.getInstance();
  var id = sp.getString('did');
  if (id == null) {
    id = '${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 31)}';
    await sp.setString('did', id);
  }
  return id;
}

String emailOf(String u) => '${u.trim().toLowerCase()}@volcan.app';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await Supabase.initialize(url: kUrl, anonKey: kAnon);
  runApp(const VolcanApp());
}

class VolcanApp extends StatelessWidget {
  const VolcanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Volcan TV',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF12161B),
          colorScheme: const ColorScheme.dark(primary: kOrange),
        ),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Gate(),
      );
}

/// يقرر أي شاشة تظهر: دخول / تفعيل / الرئيسية
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Map<String, dynamic>? profile;
  bool loading = true, blocked = false;

  @override
  void initState() {
    super.initState();
    sb.auth.onAuthStateChange.listen((_) => load());
    load();
  }

  Future<void> load() async {
    if (sb.auth.currentUser == null) {
      if (mounted) setState(() { profile = null; loading = false; });
      return;
    }
    final p = await sb.from('profiles').select().eq('id', sb.auth.currentUser!.id).maybeSingle();
    var b = false;
    if (p != null) {
      try {
        await sb.rpc('register_device', params: {'p_device': await deviceId()});
      } catch (_) {
        b = true;
      }
    }
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) setState(() { profile = p; blocked = b; loading = false; });
  }

  bool get active {
    final e = profile?['expires_at'];
    return e != null && DateTime.parse(e).isAfter(DateTime.now());
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: Logo(size: 140)));
    if (blocked) return const DeviceLimitPage();
    if (profile == null) return AuthPage(onDone: load);
    if (!active) return ActivatePage(onDone: load);
    return HomePage(profile: profile!, onChanged: load);
  }
}

class Logo extends StatelessWidget {
  final double size;
  const Logo({super.key, this.size = 110});
  @override
  Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
        ClipRRect(borderRadius: BorderRadius.circular(size * .22), child: Image.asset('assets/logo.png', width: size, height: size)),
        const SizedBox(height: 10),
        const Text('VOLCAN TV', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, letterSpacing: 1)),
      ]);
}

class DeviceLimitPage extends StatelessWidget {
  const DeviceLimitPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Logo(),
              const SizedBox(height: 24),
              const Text('تم الوصول للحد الأقصى من الأجهزة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('هذا الحساب مرتبط بجهاز آخر. تواصل مع الموزّع لإعادة ضبط الأجهزة.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              OutlinedButton(onPressed: () => sb.auth.signOut(), child: const Text('تسجيل الخروج')),
            ]),
          ),
        ),
      );
}

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class AuthPage extends StatefulWidget {
  final VoidCallback onDone;
  const AuthPage({super.key, required this.onDone});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final u = TextEditingController(), p = TextEditingController();
  bool reg = false, busy = false;

  Future<void> submit() async {
    final name = u.text.trim().toLowerCase();
    if (name.length < 3 || p.text.length < 6) {
      toast(context, 'الاسم 3 أحرف على الأقل وكلمة المرور 6 على الأقل');
      return;
    }
    setState(() => busy = true);
    try {
      if (reg) {
        await sb.auth.signUp(email: emailOf(name), password: p.text, data: {'username': name});
      } else {
        await sb.auth.signInWithPassword(email: emailOf(name), password: p.text);
      }
      widget.onDone();
    } on AuthException catch (e) {
      if (mounted) toast(context, (reg ? 'تعذّر إنشاء الحساب: ' : 'تعذّر الدخول: ') + e.message);
      debugPrint(e.message);
    } catch (e) {
      if (mounted) toast(context, 'خطأ: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const Logo(),
                const SizedBox(height: 32),
                TextField(controller: u, decoration: const InputDecoration(labelText: 'اسم المستخدم')),
                const SizedBox(height: 12),
                TextField(controller: p, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور')),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: FilledButton(onPressed: busy ? null : submit, child: Text(reg ? 'إنشاء حساب' : 'دخول')),
                ),
                TextButton(
                  onPressed: () => setState(() => reg = !reg),
                  child: Text(reg ? 'لديك حساب؟ سجّل الدخول' : 'ليس لديك حساب؟ أنشئ حسابًا'),
                ),
              ]),
            ),
          ),
        ),
      );
}

class ActivatePage extends StatefulWidget {
  final VoidCallback onDone;
  const ActivatePage({super.key, required this.onDone});
  @override
  State<ActivatePage> createState() => _ActivatePageState();
}

class _ActivatePageState extends State<ActivatePage> {
  final c = TextEditingController();
  bool busy = false;

  Future<void> redeem() async {
    setState(() => busy = true);
    try {
      await sb.rpc('redeem_code', params: {'p_code': c.text});
      widget.onDone();
    } catch (_) {
      if (mounted) toast(context, 'كود غير صالح أو مستخدم');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const Logo(),
                const SizedBox(height: 24),
                const Text('تفعيل الاشتراك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                const Text('أدخل كود التفعيل الذي حصلت عليه من الموزّع', textAlign: TextAlign.center),
                const SizedBox(height: 20),
                TextField(
                  controller: c,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.ltr,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(hintText: 'VOLCAN-XXXX'),
                ),
                const SizedBox(height: 16),
                SizedBox(width: double.infinity, height: 48, child: FilledButton(onPressed: busy ? null : redeem, child: const Text('تفعيل'))),
                TextButton(onPressed: () => sb.auth.signOut(), child: const Text('تسجيل الخروج')),
              ]),
            ),
          ),
        ),
      );
}

// ===================== أدوات مشتركة =====================
String kindTitle(String k) => {'live': 'بث مباشر', 'movie': 'أفلام', 'series': 'مسلسلات', 'sports': 'Sports'}[k] ?? k;

void openSection(BuildContext c, String kind, {bool replace = false}) {
  final Widget page = kind == 'live' ? const LivePage() : ChannelsPage(kind: kind, title: kindTitle(kind));
  final route = MaterialPageRoute(builder: (_) => page);
  if (replace) {
    Navigator.pushReplacement(c, route);
  } else {
    Navigator.push(c, route);
  }
}

Future<List<Map<String, dynamic>>> fetchChannels(String kind) async {
  final r = await sb.from('channels').select().eq('active', true).eq('kind', kind).order('name');
  return List<Map<String, dynamic>>.from(r);
}

Future<Set<int>> fetchFavs() async {
  final f = await sb.from('favorites').select('channel_id');
  return {for (final x in f) x['channel_id'] as int};
}

Future<void> setFav(int id, bool on) async {
  if (on) {
    await sb.from('favorites').insert({'channel_id': id});
  } else {
    await sb.from('favorites').delete().eq('channel_id', id);
  }
}

Future<List<int>> getRecent(String kind) async {
  final sp = await SharedPreferences.getInstance();
  return (sp.getStringList('recent_$kind') ?? <String>[]).map((e) => int.parse(e)).toList();
}

Future<void> addRecent(String kind, int id) async {
  final sp = await SharedPreferences.getInstance();
  final l = sp.getStringList('recent_$kind') ?? <String>[];
  l.remove('$id');
  l.insert(0, '$id');
  await sp.setStringList('recent_$kind', l.take(50).toList());
}

Future<void> clearRecent() async {
  final sp = await SharedPreferences.getInstance();
  for (final k in ['live', 'movie', 'series', 'sports']) {
    await sp.remove('recent_$k');
  }
}

String catLabel(String cat) {
  if (cat == 'ALL') return 'ALL';
  if (cat == '__fav') return 'المفضلة';
  if (cat == '__recent') return 'شوهدت مؤخراً';
  return cat;
}

List<Map<String, dynamic>> applyFilter(List<Map<String, dynamic>> all, Set<int> favs, List<int> recent, String cat, String q) {
  final ql = q.toLowerCase();
  Iterable<Map<String, dynamic>> r = all;
  if (cat == '__fav') {
    r = r.where((e) => favs.contains(e['id']));
  } else if (cat == '__recent') {
    r = recent.map((id) => all.where((e) => e['id'] == id)).expand((x) => x);
  } else if (cat != 'ALL') {
    r = r.where((e) => (e['category'] ?? 'عام').toString() == cat);
  }
  if (ql.isNotEmpty) {
    r = r.where((e) => e['name'].toString().toLowerCase().contains(ql));
  }
  return r.toList();
}

class Bg extends StatelessWidget {
  final Widget child;
  const Bg({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        color: const Color(0xFF0A0906),
        child: CustomPaint(painter: StripesPainter(), child: child),
      );
}

/// الشريط العلوي: تبويبات الأقسام + البحث + الشعار
class TopNav extends StatelessWidget {
  final String current;
  final ValueChanged<String> onSearch;
  const TopNav({super.key, required this.current, required this.onSearch});

  Widget tab(BuildContext c, String label, String kind) {
    final sel = current == kind;
    return InkWell(
      onTap: () {
        if (sel) return;
        if (kind == 'home') {
          Navigator.popUntil(c, (r) => r.isFirst);
        } else {
          openSection(c, kind, replace: true);
        }
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        child: Text(label, style: TextStyle(fontSize: 15, color: sel ? kGold : Colors.white70, fontWeight: sel ? FontWeight.bold : FontWeight.normal)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Container(
        height: 52,
        decoration: const BoxDecoration(color: Color(0xCC000000), border: Border(bottom: BorderSide(color: Color(0x66D4AF37)))),
        child: Row(children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/logo.png', height: 36)),
          ),
          SizedBox(
            width: 200,
            child: TextField(
              onChanged: onSearch,
              style: const TextStyle(fontSize: 13),
              decoration: InputDecoration(
                isDense: true,
                hintText: 'بحث',
                prefixIcon: const Icon(Icons.search, color: kGold, size: 18),
                filled: true,
                fillColor: const Color(0xFF161C22),
                contentPadding: EdgeInsets.zero,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: Color(0x66D4AF37))),
              ),
            ),
          ),
          Expanded(
            child: ListView(scrollDirection: Axis.horizontal, children: [
              tab(context, 'مسلسلات', 'series'),
              tab(context, 'أفلام', 'movie'),
              tab(context, 'Sports', 'sports'),
              tab(context, 'بث مباشر', 'live'),
              tab(context, 'الرئيسية', 'home'),
            ]),
          ),
        ]),
      );
}

/// قائمة الفئات الجانبية (مع عدد كل فئة)
class CatSidebar extends StatelessWidget {
  final List<Map<String, dynamic>> channels;
  final Set<int> favs;
  final List<int> recent;
  final String cat;
  final ValueChanged<String> onCat;
  final double width;
  const CatSidebar({super.key, required this.channels, required this.favs, required this.recent, required this.cat, required this.onCat, this.width = 200});

  Widget item(String label, int n, String key) {
    final sel = cat == key;
    return InkWell(
      onTap: () => onCat(key),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
        decoration: BoxDecoration(color: sel ? const Color(0x33D4AF37) : const Color(0x66000000), borderRadius: BorderRadius.circular(8)),
        child: Row(children: [
          Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, color: sel ? kGold : Colors.white))),
          Text('$n', style: TextStyle(fontSize: 12, color: sel ? kGold : Colors.grey)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final counts = <String, int>{};
    for (final e in channels) {
      final k = (e['category'] ?? 'عام').toString();
      counts[k] = (counts[k] ?? 0) + 1;
    }
    final cats = counts.keys.toList()..sort();
    final recentN = recent.where((id) => channels.any((e) => e['id'] == id)).length;
    final favN = channels.where((e) => favs.contains(e['id'])).length;
    return Container(
      width: width,
      color: const Color(0x99000000),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: InkWell(
            onTap: () => Navigator.pop(context),
            child: const Row(children: [
              Icon(Icons.keyboard_return, color: kGold, size: 18),
              SizedBox(width: 6),
              Text('عودة', style: TextStyle(color: kGold)),
            ]),
          ),
        ),
        Expanded(
          child: ListView(padding: EdgeInsets.zero, children: [
            item('شوهدت مؤخراً', recentN, '__recent'),
            item('ALL', channels.length, 'ALL'),
            item('المفضلة', favN, '__fav'),
            for (final c in cats) item(c, counts[c] ?? 0, c),
          ]),
        ),
      ]),
    );
  }
}

// ===================== أفلام / مسلسلات / Sports =====================
class ChannelsPage extends StatefulWidget {
  final String kind, title;
  const ChannelsPage({super.key, required this.kind, required this.title});
  @override
  State<ChannelsPage> createState() => _ChannelsPageState();
}

class _ChannelsPageState extends State<ChannelsPage> {
  String cat = 'ALL', q = '', sort = 'added';
  bool loading = true;
  List<Map<String, dynamic>> channels = [];
  Set<int> favs = {};
  List<int> recent = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final r = await fetchChannels(widget.kind);
      final f = await fetchFavs();
      final rc = await getRecent(widget.kind);
      if (!mounted) return;
      setState(() {
        channels = r;
        favs = f;
        recent = rc;
        loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> toggleFav(int id) async {
    final on = !favs.contains(id);
    setState(() {
      if (on) {
        favs.add(id);
      } else {
        favs.remove(id);
      }
    });
    try {
      await setFav(id, on);
    } catch (_) {}
  }

  Future<void> play(Map<String, dynamic> c) async {
    await addRecent(widget.kind, c['id'] as int);
    if (!mounted) return;
    final isLive = widget.kind != 'movie' && widget.kind != 'series';
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(name: c['name'].toString(), url: c['stream_url'].toString(), live: isLive)));
    final rc = await getRecent(widget.kind);
    if (mounted) setState(() => recent = rc);
  }

  Widget poster(Map<String, dynamic> c) {
    final id = c['id'] as int;
    final logo = c['logo_url'] as String?;
    final hasLogo = logo != null && logo.isNotEmpty;
    final fallback = Container(
      color: const Color(0xFF1B232A),
      alignment: Alignment.center,
      child: const Icon(Icons.movie_outlined, size: 40, color: kGold),
    );
    return InkWell(
      onTap: () => play(c),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(
          child: Stack(fit: StackFit.expand, children: [
            hasLogo ? Image.network(logo!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback) : fallback,
            Positioned(
              top: 3,
              left: 3,
              child: GestureDetector(
                onTap: () => toggleFav(id),
                child: Container(
                  padding: const EdgeInsets.all(5),
                  decoration: const BoxDecoration(color: Color(0x99000000), shape: BoxShape.circle),
                  child: Icon(favs.contains(id) ? Icons.favorite : Icons.favorite_border, color: kGold, size: 16),
                ),
              ),
            ),
          ]),
        ),
        Container(
          color: const Color(0xFF2A210D),
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 7),
          child: Text(c['name'].toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = applyFilter(channels, favs, recent, cat, q);
    if (cat != '__recent') {
      if (sort == 'name') {
        list.sort((a, b) => a['name'].toString().compareTo(b['name'].toString()));
      } else {
        list.sort((a, b) => (b['id'] as int).compareTo(a['id'] as int));
      }
    }

    final content = Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 0),
        child: Row(children: [
          Text('${catLabel(cat)} (${list.length})', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: kGoldLight)),
          const Spacer(),
          DropdownButton<String>(
            value: sort,
            dropdownColor: const Color(0xFF1A1A1A),
            underline: const SizedBox(),
            items: const [
              DropdownMenuItem(value: 'added', child: Text('حسب ما تم اضافته')),
              DropdownMenuItem(value: 'name', child: Text('حسب الاسم')),
            ],
            onChanged: (v) => setState(() => sort = v ?? 'added'),
          ),
        ]),
      ),
      Expanded(
        child: loading
            ? const Center(child: CircularProgressIndicator(color: kGold))
            : list.isEmpty
                ? const Center(child: Text('لا يوجد محتوى', style: TextStyle(color: Colors.grey)))
                : GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 130, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 0.62),
                    itemCount: list.length,
                    itemBuilder: (_, i) => poster(list[i]),
                  ),
      ),
    ]);

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Bg(
        child: SafeArea(
          child: Column(children: [
            TopNav(current: widget.kind, onSearch: (v) => setState(() => q = v)),
            Expanded(
              child: Row(children: [
                Expanded(child: content),
                CatSidebar(channels: channels, favs: favs, recent: recent, cat: cat, onCat: (v) => setState(() => cat = v)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

// ===================== البث المباشر: 3 أقسام =====================
class LivePage extends StatefulWidget {
  const LivePage({super.key});
  @override
  State<LivePage> createState() => _LivePageState();
}

class _LivePageState extends State<LivePage> {
  String cat = 'ALL', q = '';
  bool loading = true, failed = false;
  List<Map<String, dynamic>> channels = [];
  Set<int> favs = {};
  List<int> recent = [];
  Map<String, dynamic>? sel;
  VideoPlayerController? vc;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    load();
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    vc?.dispose();
    super.dispose();
  }

  Future<void> load() async {
    try {
      final r = await fetchChannels('live');
      final f = await fetchFavs();
      final rc = await getRecent('live');
      if (!mounted) return;
      setState(() {
        channels = r;
        favs = f;
        recent = rc;
        loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> select(Map<String, dynamic> c) async {
    final old = vc;
    setState(() {
      sel = c;
      vc = null;
      failed = false;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => old?.dispose());
    addRecent('live', c['id'] as int);
    final n = VideoPlayerController.networkUrl(Uri.parse(c['stream_url'].toString()));
    try {
      await n.initialize();
    } catch (_) {
      n.dispose();
      if (mounted && sel == c) setState(() => failed = true);
      return;
    }
    if (!mounted || sel != c) {
      n.dispose();
      return;
    }
    await n.play();
    setState(() => vc = n);
    final rc = await getRecent('live');
    if (mounted) setState(() => recent = rc);
  }

  Future<void> full() async {
    final c = sel;
    if (c == null) return;
    vc?.pause();
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(name: c['name'].toString(), url: c['stream_url'].toString())));
    if (mounted) vc?.play();
  }

  Future<void> toggleFav(int id) async {
    final on = !favs.contains(id);
    setState(() {
      if (on) {
        favs.add(id);
      } else {
        favs.remove(id);
      }
    });
    try {
      await setFav(id, on);
    } catch (_) {}
  }

  Widget video() {
    final v = vc;
    if (v != null && v.value.isInitialized) {
      return Center(child: AspectRatio(aspectRatio: v.value.aspectRatio, child: VideoPlayer(v)));
    }
    if (failed) return const Center(child: Text('تعذّر تشغيل القناة', style: TextStyle(color: Colors.grey)));
    if (sel == null) return const Center(child: Icon(Icons.live_tv, color: kGold, size: 48));
    return const Center(child: CircularProgressIndicator(color: kGold));
  }

  Widget row(int i, Map<String, dynamic> c) {
    final id = c['id'] as int;
    final on = sel != null && sel!['id'] == id;
    final logo = c['logo_url'] as String?;
    const fallback = Icon(Icons.tv, size: 18, color: kGold);
    return InkWell(
      onTap: () => on ? full() : select(c),
      child: Container(
        color: on ? const Color(0x33D4AF37) : Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
        child: Row(children: [
          SizedBox(width: 28, child: Text('${i + 1}', style: const TextStyle(color: Colors.grey, fontSize: 12))),
          SizedBox(
            width: 26,
            height: 26,
            child: (logo != null && logo.isNotEmpty) ? Image.network(logo, errorBuilder: (_, __, ___) => fallback) : fallback,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(c['name'].toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, color: on ? kGold : Colors.white))),
          if (favs.contains(id)) const Icon(Icons.favorite, size: 14, color: kGold),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = applyFilter(channels, favs, recent, cat, q);
    final s = sel;
    final isFav = s != null && favs.contains(s['id']);

    final preview = SingleChildScrollView(
      padding: const EdgeInsets.all(10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        AspectRatio(aspectRatio: 16 / 9, child: Container(color: Colors.black, child: video())),
        const SizedBox(height: 10),
        Text(s == null ? 'اختر قناة' : s['name'].toString(), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kGoldLight)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton.icon(
            onPressed: s == null ? null : full,
            icon: const Icon(Icons.fullscreen, color: kGold),
            label: const Text('ملء الشاشة', style: TextStyle(color: Colors.white)),
            style: OutlinedButton.styleFrom(side: const BorderSide(color: kGold)),
          ),
          OutlinedButton.icon(
            onPressed: s == null ? null : () => toggleFav(s['id'] as int),
            icon: Icon(isFav ? Icons.favorite : Icons.favorite_border, color: kGold),
            label: Text(isFav ? 'إزالة من المفضلة' : 'إضافة الى المفضلة', style: const TextStyle(color: Colors.white)),
            style: OutlinedButton.styleFrom(side: const BorderSide(color: kGold)),
          ),
        ]),
      ]),
    );

    final listPane = Container(
      width: 240,
      color: const Color(0x66000000),
      child: loading
          ? const Center(child: CircularProgressIndicator(color: kGold))
          : list.isEmpty
              ? const Center(child: Text('لا توجد قنوات', style: TextStyle(color: Colors.grey)))
              : ListView.builder(itemCount: list.length, itemBuilder: (_, i) => row(i, list[i])),
    );

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Bg(
        child: SafeArea(
          child: Column(children: [
            TopNav(current: 'live', onSearch: (v) => setState(() => q = v)),
            Expanded(
              child: Row(children: [
                Expanded(child: preview),
                listPane,
                CatSidebar(channels: channels, favs: favs, recent: recent, cat: cat, width: 170, onCat: (v) => setState(() => cat = v)),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}

const kGold = Color(0xFFD4AF37);
const kGoldLight = Color(0xFFF3D77A);

/// خلفية بخطوط ذهبية مائلة
class StripesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final thin = Paint()..color = const Color(0x14D4AF37)..strokeWidth = 1.2;
    for (double x = -size.height; x < size.width; x += 44) {
      canvas.drawLine(Offset(x, size.height), Offset(x + size.height, 0), thin);
    }
    final band = Paint()..color = const Color(0x1AD4AF37)..strokeWidth = 18;
    canvas.drawLine(Offset(size.width * .15, size.height), Offset(size.width * .55, 0), band);
    canvas.drawLine(Offset(size.width * .62, size.height), Offset(size.width * 1.0, 0), band);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class GoldTile extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final double iconSize, fs;
  final bool live;
  const GoldTile({super.key, required this.icon, required this.label, required this.onTap, this.iconSize = 44, this.fs = 17, this.live = false});
  @override
  State<GoldTile> createState() => _GoldTileState();
}

class _GoldTileState extends State<GoldTile> {
  bool focus = false, hover = false;
  bool get on => focus || hover;

  @override
  Widget build(BuildContext context) => FocusableActionDetector(
        onShowFocusHighlight: (v) => setState(() => focus = v),
        onShowHoverHighlight: (v) => setState(() => hover = v),
        actions: {ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (_) { widget.onTap(); return null; })},
        child: GestureDetector(
          onTap: widget.onTap,
          child: AnimatedScale(
            scale: on ? 1.04 : 1,
            duration: const Duration(milliseconds: 160),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF24313A), Color(0xFF11181D)]),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: on ? kGoldLight : const Color(0x55D4AF37), width: on ? 2 : 1),
                boxShadow: [BoxShadow(color: on ? kGold.withOpacity(.4) : Colors.black54, blurRadius: on ? 20 : 8, offset: const Offset(0, 4))],
              ),
              child: Stack(children: [
                if (widget.live)
                  Positioned(
                    top: 10,
                    right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(color: const Color(0xFFD71920), borderRadius: BorderRadius.circular(20)),
                      child: const Text('● LIVE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold)),
                    ),
                  ),
                Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      padding: EdgeInsets.all(widget.iconSize * .32),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [kGold.withOpacity(.28), Colors.transparent]),
                      ),
                      child: ShaderMask(
                        shaderCallback: (r) => const LinearGradient(colors: [kGoldLight, kGold, Color(0xFF9C7A1C)], begin: Alignment.topCenter, end: Alignment.bottomCenter).createShader(r),
                        child: Icon(widget.icon, size: widget.iconSize, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(widget.label, textAlign: TextAlign.center, style: TextStyle(fontSize: widget.fs, fontWeight: FontWeight.w600)),
                  ]),
                ),
              ]),
            ),
          ),
        ),
      );
}

/// زر عريض بإطار ذهبي (للرئيسية والإعدادات)
class WideBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;
  const WideBtn({super.key, required this.icon, required this.label, required this.onTap, this.color});
  @override
  Widget build(BuildContext context) {
    final c = color ?? kGold;
    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF24313A), Color(0xFF11181D)]),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: c.withOpacity(.6)),
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(children: [
              Icon(icon, color: c, size: 24),
              const SizedBox(width: 12),
              Expanded(child: Text(label, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: color ?? Colors.white, fontSize: 14))),
            ]),
          ),
        ),
      ),
    );
  }
}

/// الشاشة الرئيسية
class HomePage extends StatelessWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const HomePage({super.key, required this.profile, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final exp = DateTime.parse(profile['expires_at']).toLocal();
    final date = '${exp.day}/${exp.month}/${exp.year}';
    final left = exp.difference(DateTime.now()).inDays;
    const gap = SizedBox(width: 12, height: 12);
    return Scaffold(
      body: Bg(
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
            child: Column(children: [
              Row(children: [
                Expanded(
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text('اشتراكك ينتهي: $date  ($left يوم)', style: const TextStyle(fontSize: 12.5, color: Colors.white70)),
                  ),
                ),
                Column(mainAxisSize: MainAxisSize.min, children: [
                  ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.asset('assets/logo.png', height: 48)),
                  ShaderMask(
                    shaderCallback: (r) => const LinearGradient(colors: [kGoldLight, kGold]).createShader(r),
                    child: const Text('VOLCAN TV', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: 1.5, color: Colors.white)),
                  ),
                ]),
                Expanded(
                  child: Align(
                    alignment: AlignmentDirectional.centerEnd,
                    child: Text('أهلاً، ${profile['username']}', style: const TextStyle(fontSize: 13, color: Colors.grey)),
                  ),
                ),
              ]),
              const SizedBox(height: 10),
              Expanded(
                child: Row(children: [
                  Expanded(
                    flex: 4,
                    child: Column(children: [
                      Expanded(child: WideBtn(icon: Icons.settings, label: 'الإعدادات', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage(profile: profile, onChanged: onChanged))))),
                      gap,
                      Expanded(child: WideBtn(icon: Icons.refresh, label: 'إعادة تحميل البوابة', onTap: () { onChanged(); toast(context, 'تم التحديث'); })),
                      gap,
                      Expanded(child: WideBtn(icon: Icons.logout, label: 'خروج', onTap: () => SystemNavigator.pop())),
                    ]),
                  ),
                  gap,
                  Expanded(
                    flex: 4,
                    child: Column(children: [
                      Expanded(child: GoldTile(icon: Icons.video_library, label: 'مسلسلات', onTap: () => openSection(context, 'series'))),
                      gap,
                      Expanded(child: GoldTile(icon: Icons.autorenew, label: 'تجديد الاشتراك', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ActivatePage(onDone: () { Navigator.pop(context); onChanged(); }))))),
                    ]),
                  ),
                  gap,
                  Expanded(
                    flex: 4,
                    child: Column(children: [
                      Expanded(child: GoldTile(icon: Icons.movie_outlined, label: 'أفلام', onTap: () => openSection(context, 'movie'))),
                      gap,
                      Expanded(child: GoldTile(icon: Icons.sports_soccer, label: 'Sports', onTap: () => openSection(context, 'sports'))),
                    ]),
                  ),
                  gap,
                  Expanded(flex: 6, child: GoldTile(icon: Icons.live_tv, label: 'بث مباشر', iconSize: 80, fs: 26, live: true, onTap: () => openSection(context, 'live'))),
                ]),
              ),
              const SizedBox(height: 4),
              const Align(alignment: Alignment.bottomRight, child: Text('v2.0', style: TextStyle(fontSize: 14, color: Colors.grey))),
            ]),
          ),
        ),
      ),
    );
  }
}

/// الإعدادات: شبكة أزرار
class SettingsPage extends StatefulWidget {
  final Map<String, dynamic> profile;
  final VoidCallback onChanged;
  const SettingsPage({super.key, required this.profile, required this.onChanged});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  Future<void> changePassword() async {
    final oldC = TextEditingController();
    final newC = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تغيير كلمة المرور'),
        content: SizedBox(
          width: 320,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: oldC, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور الحالية')),
            TextField(controller: newC, obscureText: true, decoration: const InputDecoration(labelText: 'الجديدة (6 أحرف على الأقل)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok != true) return;
    if (newC.text.length < 6) {
      if (mounted) toast(context, 'كلمة المرور الجديدة قصيرة');
      return;
    }
    try {
      await sb.auth.signInWithPassword(email: emailOf(widget.profile['username'].toString()), password: oldC.text);
      await sb.auth.updateUser(UserAttributes(password: newC.text));
      if (mounted) toast(context, 'تم تغيير كلمة المرور');
    } on AuthException catch (e) {
      if (mounted) toast(context, 'تعذّر: ${e.message}');
    } catch (e) {
      if (mounted) toast(context, 'خطأ: $e');
    }
  }

  Future<void> clearFavs() async {
    try {
      await sb.from('favorites').delete().neq('channel_id', -1);
      if (mounted) toast(context, 'تم مسح المفضلة');
    } catch (e) {
      if (mounted) toast(context, 'خطأ: $e');
    }
  }

  Future<void> clearHistory() async {
    await clearRecent();
    if (mounted) toast(context, 'تم مسح سجل المشاهدة');
  }

  void about() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Volcan TV'),
        content: Text('الإصدار 2.0\nالمستخدم: ${widget.profile['username']}'),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('حسناً'))],
      ),
    );
  }

  void activate() => Navigator.push(context, MaterialPageRoute(builder: (_) => ActivatePage(onDone: () { Navigator.pop(context); widget.onChanged(); })));

  @override
  Widget build(BuildContext context) {
    final exp = DateTime.parse(widget.profile['expires_at']).toLocal();
    final left = exp.difference(DateTime.now()).inDays;
    return Scaffold(
      body: Bg(
        child: SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
              child: Row(children: [
                const SizedBox(width: 48),
                const Expanded(child: Center(child: Text('الإعدادات', style: TextStyle(fontSize: 22, color: kGoldLight, fontWeight: FontWeight.bold)))),
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.keyboard_return, color: kGold, size: 28)),
              ]),
            ),
            Expanded(
              child: GridView.count(
                crossAxisCount: 4,
                padding: const EdgeInsets.all(16),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 2.8,
                children: [
                  WideBtn(icon: Icons.translate, label: 'تغيير اللغة', onTap: () => toast(context, 'العربية هي اللغة المتاحة حالياً')),
                  WideBtn(icon: Icons.lock, label: 'تغيير كلمة المرور', onTap: changePassword),
                  WideBtn(icon: Icons.vpn_key, label: 'تجديد / رمز التفعيل', onTap: activate),
                  WideBtn(icon: Icons.refresh, label: 'تحديث المحتوى', onTap: () { widget.onChanged(); toast(context, 'تم التحديث'); }),
                  WideBtn(icon: Icons.favorite_border, label: 'مسح المفضلة', onTap: clearFavs),
                  WideBtn(icon: Icons.history, label: 'مسح سجل المشاهدة', onTap: clearHistory),
                  WideBtn(icon: Icons.info_outline, label: 'عن التطبيق', onTap: about),
                  WideBtn(icon: Icons.logout, label: 'تسجيل الخروج', color: Colors.redAccent, onTap: () { Navigator.pop(context); sb.auth.signOut(); }),
                ],
              ),
            ),
            FutureBuilder<String>(
              future: deviceId(),
              builder: (_, s) {
                final d = s.data ?? '';
                final short = d.length > 6 ? d.substring(d.length - 6) : d;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text('المستخدم: ${widget.profile['username']}  ·  ينتهي: ${exp.day}/${exp.month}/${exp.year} ($left يوم)\nمفتاح الجهاز: $short', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                );
              },
            ),
          ]),
        ),
      ),
    );
  }
}

class PlayerPage extends StatefulWidget {
  final String name, url;
  final bool live;
  const PlayerPage({super.key, required this.name, required this.url, this.live = true});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final VideoPlayerController vc;
  ChewieController? cc;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    vc = VideoPlayerController.networkUrl(Uri.parse(widget.url))
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() => cc = ChewieController(videoPlayerController: vc, autoPlay: true, isLive: widget.live, aspectRatio: vc.value.aspectRatio));
      });
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    cc?.dispose();
    vc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.name)),
        body: Center(child: cc == null ? const CircularProgressIndicator() : Chewie(controller: cc!)),
      );
}
