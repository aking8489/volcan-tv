#!/bin/bash
set -e
cd "$(dirname "$0")/app"
flutter create . --platforms=android --org com.volcan --project-name volcan_tv
python3 - <<'PY'
p = "android/app/src/main/AndroidManifest.xml"
s = open(p).read()
s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application android:usesCleartextTraffic="true"', 1)
open(p, "w").write(s)
PY
# تعطيل فحص lint (يتعطل داخل أدوات أندرويد ولا يؤثر على الـ APK)
python3 - <<'PY'
import os, re
for f in ("android/app/build.gradle.kts", "android/app/build.gradle"):
    if os.path.exists(f):
        s = open(f).read()
        if "checkReleaseBuilds" not in s:
            s = re.sub(r"(\n\s*android\s*\{)", r"\1\n    lint {\n        checkReleaseBuilds = false\n        abortOnError = false\n    }", s, count=1)
            open(f, "w").write(s)
        print("lint disabled in", f)
PY
flutter pub get
dart run flutter_launcher_icons || echo "icons skipped"
# فحص الأخطاء وإظهارها بأعلى صفحة التشغيل
flutter analyze --no-pub 2>&1 | grep -E "^ *error" | head -10 | while IFS= read -r l; do echo "::error::$l"; done || true
set +e
flutter build apk --release --dart-define=SB_URL="$SB_URL" --dart-define=SB_KEY="$SB_KEY" 2>&1 | tee ../build.log
rc=${PIPESTATUS[0]}
if [ "$rc" -ne 0 ]; then
  grep -nE "Error|error:|What went wrong" -A2 ../build.log | head -8 | while IFS= read -r l; do echo "::error::$l"; done
  exit "$rc"
fi
