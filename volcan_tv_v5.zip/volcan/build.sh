#!/bin/bash
set -e
cd "$(dirname "$0")/app"
flutter create . --platforms=android --org com.volcan --project-name volcan_tv
python3 - <<'PY'
p = "android/app/src/main/AndroidManifest.xml"
s = open(p).read()
s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application android:usesCleartextTraffic="true"', 1)
open(p, "w").write(s)
PY
flutter pub get
dart run flutter_launcher_icons || echo "icons skipped"
# فحص الأخطاء وإظهارها بأعلى صفحة التشغيل
flutter analyze --no-pub 2>&1 | grep -E "^ *error" | head -10 | while IFS= read -r l; do echo "::error::$l"; done || true
set +e
flutter build apk --release --dart-define=SB_URL="$SB_URL" --dart-define=SB_KEY="$SB_KEY" 2>&1 | tee ../build.log
rc=${PIPESTATUS[0]}
if [ "$rc" -ne 0 ]; then
  grep -nE "Error|error:|What went wrong" -A2 ../build.log | head -8 | while IFS= read -r l; do echo "::error::$l"; done
  exit "$rc"
fi
